Croc's Hoi4 Logging Tool
v 1.0
Requres .NET 6.0 runtime to run

Tool to filter and search through hoi4 logs.
Note: "country" filter is set up to work with MD standart. [TAG]:
All dates need to be in format year.month.day - example: 2000.01.01
Select folder to load the logs - folder to be selected is: Documents\Paradox Interactive\Hearts of Iron IV\logs

App may be a bit greedy on RAM, and filter reloads cause it to lag.